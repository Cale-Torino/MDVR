$(function() {
	var local=$.kui.util.getUrlParam("language");
	if(local){
		window.sessionStorage.setItem("language",local);
		langChange(local);
	}else{
		langInitByBrowser();
	}
});

function langChange(local,func){
	var n=0;//每次执行一次即可
	var basePath = window.location.href;
	var basePahts= basePath.split('?');
	var basePathIndex=basePath.split('?').length-1;
	if(basePathIndex>0){
		basePath=basePahts[0];
	}
	if(basePath.indexOf("index.html")>0
			||basePath.indexOf("api.do")>0
			||basePath.indexOf("login.html")>0)
	{
		basePath=basePath.replace("api.do", "");
		basePath=basePath.replace("index.html", "");
		basePath=basePath.replace("login.html", "");
	}
	var t1 = window.setInterval(function(){
		if(!$.language){
			if(n==0){
				//根据local动态加载js
				var script = document.createElement("script");
				script.type = "text/javascript";
				script.src = basePath+"/js/language/"+getFileName(local);
				document.head.appendChild(script);
				n++;
			}else{
				try{
					$.language=new language();
					if($.language){
						$.language.init($);//对部分控件语言进行设置
						window.clearInterval(t1);
						if(func){
							func();
						}
					}
				}catch(err){
					console.log('多语言资源加载失败，重新开始加重！');
				}
			}
		}else{
			//根据local动态加载js
			var script = document.createElement("script");
			script.type = "text/javascript";
			if(!local){
				local="CN";
			}	
			script.src = basePath+"/js/language/"+getFileName(local);
			document.head.appendChild(script);
			n++;
			$.language=null;
			
				
			
		}
	 },100); 
}

function getFileName(local){
	if(!local){
		return "lang_zh.js";
	}
	if (local.indexOf('en') > -1){
   		return "lang_en.js";
   	} else if(local.indexOf('CN') > -1 || local.indexOf('cn') > -1){
   		return "lang_zh.js";
   	//} else if(local.indexOf('RU') > -1 || local.indexOf('ru') > -1){
   	//	return "lang_ru.js";
   	}else {
   		return "lang_zh.js";	//默认
   	}
}

function langInitByBrowser() {
	//先从store中获取语言参数
	var local = window.sessionStorage.getItem("language"); //$.kui.store.get("language");
	if (local == null) {
		//再跟据浏览器语言获取语言参数
		if (navigator.userAgent.indexOf('MSIE') >= 0){
			local = navigator.browserLanguage;
		}else if(navigator.userAgent.indexOf('Firefox') >= 0 || navigator.userAgent.indexOf('Chrome') >= 0 
				|| navigator.userAgent.indexOf('Opera') >= 0 || navigator.userAgent.indexOf('Mozilla') >= 0){
			local = navigator.language;
		} else {
			local = navigator.language;
		}
	   
	}
  	langChange(local);
}