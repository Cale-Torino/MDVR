function language(){
	this.init = function(jquery){
		var a = $;
		if(jquery){
			a = jquery;
		}
		//设置KTable表格语言
		if(undefined != a.fn.kuiTable){
			a.extend(a.fn.kuiTable.defaults, this.local_table);
		}
	};
	this.local = "en";
	this.local_table = {
		formatLoadingMessage: function () {
			return "You have not performed the query operation, or the current query conditions do not match the data, please change the filter criteria to re-query……";
		},
		formatRecordsPerPage: function (a) {
			return a + " records per page";
		},
		formatShowingRows: function (a, b, c) {
			return "Showing " + a + "st to " + b + "nd records, for a total of " + c + " records";
		},
		formatSearch: function () {
			return "Search for";
		},
		formatNoMatches: function () {
			return "No data";
		},
		formatPaginationSwitch: function () {
			return "Hide/Show paging";
		},
		formatRefresh: function () {
			return "Refresh";
		},
		formatToggle: function () {
			return "Switch";
		},
		formatColumns: function () {
			return "Column";
		}
	};
	this.lang = "Please select a language";
	this.lang_zh = "Chinese";
	this.lang_en = "English";
	
	this.login_wecome = "Login please";
	this.login_account = "Please enter an account login";
	this.login_password = "Please enter your password to login";
	this.login_code = "Please enter verification code";
	this.login_btn = "Login";
	this.login_result_1 = "The account does not exist";
	this.login_result_2 = "Password error";
	this.login_result_3 = "Account has expired";
	this.login_result_4 = "Verification code error";
	this.login_result_5 = "Server request failed";
	this.login_result_18 = "Login session has expired, please log in again";
	
	this.index = "Home";
	this.index_welcome = "Welcome";
	this.index_userinfo = "Personal information";
	this.index_upaw = "Change Password";
	this.index_upaw_su = "The modification is successful, please log in again!";
	this.index_upaw_er = "Old password verification failed!";
	this.index_upaw_newpaw = "Please enter a new password";
	this.index_upaw_oldpaw = "Please enter your old password";
	this.index_esc = "Drop out";
	this.index_logout = "Are you sure you want to quit?";
	this.index_caret = "Switch Menu";
	this.index_refresh = "Refresh Current";
	this.index_close = "Close Other";
	this.index_close_all = "Close All";
	
	this.layer_title = "System hint";
	this.layer_title_add="Add";
	this.layer_title_edit="Edit";
	
	this.layer_btn_yes = "Yes";
	this.layer_btn_no = "Cancel";
	this.layer_btn_close = "Close";
	this.layer_btn_save = "Save";
	this.layer_confirm = "Are you sure you want to do this?";
	this.layer_confirm_delete = "Are you sure you want to delete the selected record?";
	this.layer_confirm_delete_file = "Delete files are not recoverable. Are you sure to delete them?";
	
	this.table_index = "Number";
	this.table_id = "Action";
	this.table_time = "Create time";
	this.table_by = "Created person";

	this.btn_search = "Query";
	this.btn_replace = "Refresh";
	this.btn_delete = "Delete";
	this.btn_toexport = "Export";
	this.btn_add = "Add";
	this.btn_edit = "Edit";
	this.btn_all="All";
	this.btn_open="Open";

	this.account_account = "Login account";
	this.account_placeholder_account = "Please enter a login account";
	this.account_validator_account = "The login account cannot be empty";
	this.account_validator_account_length = "The length is an alphanumeric combination of more than 6 digits less than 30 digits!";
	this.account_password = "Login password";
	this.account_last_login_time = "Last login time";
	this.account_last_login_addr = "Last login ip";
	
	this.articte_title="Title";
	this.articte_group="Group";
	this.articte_moudule="Moudule";

}