function language(){
	this.init = function(jquery){
		var a = $;
		if(jquery){
			a = jquery;
		}
		//设置KTable表格语言
		if(undefined != a.fn.kuiTable){
			a.extend(a.fn.kuiTable.defaults, this.local_table);
		}
	};
	this.local = "zh";
	this.local_table = {
		formatLoadingMessage: function () {
			return "您没有执行查询操作，或者当前查询条件没有符合的数据，请更改筛选条件重新查询……";
		},
		formatRecordsPerPage: function (a) {
			return "每页显示 " + a + " 条记录";
		},
		formatShowingRows: function (a, b, c) {
			return "显示第 " + a + " 到第 " + b + " 条记录，总共 " + c + " 条记录";
		},
		formatSearch: function () {
			return "搜索";
		},
		formatNoMatches: function () {
			return "您没有执行查询操作，或者当前查询条件没有符合的数据，请更改筛选条件重新查询……";
		},
		formatPaginationSwitch: function () {
			return "隐藏/显示分页";
		},
		formatRefresh: function () {
			return "刷新";
		},
		formatToggle: function () {
			return "切换";
		},
		formatColumns: function () {
			return "列";
		}
	};
	this.lang = "请选择语言";
	this.lang_zh = "中文";
	this.lang_en = "英文";
	
	this.login_wecome = "欢迎登录";
	this.login_account = "请输入账户登录";
	this.login_password = "请输入您的密码登录";
	this.login_code = "请输入验证码";
	this.login_btn = "登 录";
	this.login_result_1 = "账户不存在";
	this.login_result_2 = "密码错误";
	this.login_result_3 = "账户已过期";
	this.login_result_4 = "验证码错误";
	this.login_result_5 = "服务器请求失败";
	this.login_result_18 = "登录会话已过期，请重新登录";
	
	this.index = "首页";
	this.index_welcome = "欢迎光临";
	this.index_userinfo = "个人信息";
	this.index_upaw = "修改密码";
	this.index_upaw_su = "修改成功,请重新登录系统！";
	this.index_upaw_er = "旧密码验证失败！";
	this.index_upaw_newpaw = "请输入新密码";
	this.index_upaw_oldpaw = "请输入您的旧密码";
	this.index_esc = "退出";
	this.index_logout = "您确定要退出？";
	this.index_caret = "切换菜单";
	this.index_refresh = "刷新当前";
	this.index_close = "关闭其他";
	this.index_close_all = "关闭所有";
	
	this.layer_title = "系统提示";
	this.layer_title_add="添加";
	this.layer_title_edit="编辑";
	
	this.layer_btn_yes = "确定";
	this.layer_btn_no = "取消";
	this.layer_btn_close = "关闭";
	this.layer_btn_save = "保存";
	this.layer_confirm = "您确定要执行该操作吗?";
	this.layer_confirm_delete = "您确定要删除选中的记录吗?";
	this.layer_confirm_delete_file = "删除文件不可恢复，是否确定删除?";
	
	this.msg_success = "操作成功!";
	this.msg_failed = "操作失败!";
	
	this.table_index = "序号";
	this.table_id = "操作";
	this.table_time = "创建时间";
	this.table_by = "创建人";
	
	this.btn_search = "查询";
	this.btn_replace = "刷新";
	this.btn_delete = "删除";
	this.btn_toexport = "导出";
	this.btn_add = "添加";
	this.btn_edit = "编辑";
	this.btn_all="全选";
	this.btn_open="打开";
	
	this.account_account = "登录账号";
	this.account_placeholder_account = "请输入登录账号";
	this.account_validator_account = "登录账号不能为空";
	this.account_validator_account_length = "长度是大于6位小于30位的字母数字组合!";
	this.account_password = "登录密码";
	this.account_last_login_time = "上一次登录时间";
	this.account_last_login_addr = "上一次登录ip";
	
	this.articte_title="标题";
	this.articte_group="所属分组";
	this.articte_moudule="所属模块";
}