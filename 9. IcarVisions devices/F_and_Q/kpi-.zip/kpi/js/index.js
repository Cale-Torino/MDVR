$(function() {
	$.ajax({
        url: basePath+'/index.do?t=' + new Date().getTime()+"&type=topMenu",
        success: function(obj) {
			successTop(obj);
			
        },
        error: function(jqXHR, textStatus, errorThrown) {
        	options.error(jqXHR.responseText);
        }
    });
   
});
function successTop(o) {
    if (o.result == 0) {
    	  //$.kui.contentTabs.init();
        //加载header模块
        var header_data = {
            add: 'add',
            welcome: 'welcome',
            account: null,
            userinfo: 'user info',
            upaw: 'change password',
            esc: 'exit',
            logoimg:  "/kui-logo.png",
            list: o.data
        };
        $.kui.kjax.atemplate('header', 'header', 'header.html', header_data, '#data');
        //获取首页菜单
        $.ajax({
            url: basePath+'/index.do?t=' + new Date().getTime()+"&type=getMenu&gid=0",
            success: function(obj) {
        		success(obj);
            },
            error: function(jqXHR, textStatus, errorThrown) {
            	options.error(jqXHR.responseText);
            }
        });
    } else if(o.result == 18){
        //layer.msg("没有获取到菜单信息!");
        window.location.href = "login.html";
    }
}
function success(o) {
if (o.result == 0) {
    var option = { animate: true, data: JSON.parse(o.data) };
    $('#kui-tree-menu').tree(option);
    $('.kui-tree-menu-arrow-a').click(function() {
        var obj = $('.kui-tree-menu-arrow-a');
        if ($(obj).hasClass("open")) {
            $(obj).removeClass("open");
            $("body").removeClass("big-page");
        } else {
            $(obj).addClass("open");
            $("body").addClass("big-page");
        }
    });
    // 手动通过点击模拟高亮菜单项
    $('#kui-tree-menu').on('click', 'a', function() {
        $('#kui-tree-menu li.active').removeClass('active');
        $(this).closest('li').addClass('active');
    });
} else if(o.result == 18){
    //layer.msg("没有获取到菜单信息!");
    window.location.href = "login.html";
}
}
function successMenu(o) {
	if (o.result == 0) {
	    var menu=$('#kui-tree-menu').data('kui.tree');
	    if(o.data){
	    	 menu.reload(JSON.parse(o.data));
	    }
	} else if(o.result == 18){
	    //layer.msg("没有获取到菜单信息!");
	    window.location.href = "login.html";
	}
}
function error(responseText) {
	//layer.msg(responseText);
}
function menu(gid,e){
   if(null!=gid){
	   $('.navbar-left li').removeClass('active');
	   $(e).parent().addClass('active');
	   $.ajax({
           url: basePath+'/index.do?t=' + new Date().getTime()+"&type=getMenu&gid="+gid,
           success: function(obj) {
		   		successMenu(obj);
           },
           error: function(jqXHR, textStatus, errorThrown) {
           	options.error(jqXHR.responseText);
           }
       });
   }
}


function getBrowserInfo(){
    var agent = navigator.userAgent.toLowerCase() ;
    var regStr_ie = /msie [\d.]+;/gi ;
    var regStr_ff = /firefox\/[\d.]+/gi
    var regStr_chrome = /chrome\/[\d.]+/gi ;
    var regStr_saf = /safari\/[\d.]+/gi ;
    //IE
    if(agent.indexOf("msie") > 0){
        return agent.match(regStr_ie) ;
    }
    //IE11
    if(!!window.ActiveXObject || "ActiveXObject" in window){
		return 'IE11' ;
	}
    //firefox
    if(agent.indexOf("firefox") > 0){
        return agent.match(regStr_ff) ;
    }

    //Chrome
    if(agent.indexOf("chrome") > 0){
        return agent.match(regStr_chrome) ;
    }

    //Safari
    if(agent.indexOf("safari") > 0 && agent.indexOf("chrome") < 0){
        return agent.match(regStr_saf) ;
    }

}