var basePath = window.location.href;
var basePahts= basePath.split('?');
var basePathIndex=basePath.split('?').length-1;
if(basePathIndex>0){
	basePath=basePahts[0];
}
if(basePath.indexOf("index.html")>0){
	basePath=basePath.replace("index.html", "");
}
function dateFormatValue(value) {
	if (value <= 9) {
		return "0" + value;
	} else {
		return value;
	}
}
//转换成 2012-05-11 的格式		短时间格式
function dateFormatDateString(date) {
	var str = date.getFullYear() + "-" + dateFormatValue(date.getMonth() + 1) + "-" + dateFormatValue(date.getDate());
	return str;
}
//转换成 2012-05-11 11:20:20的格式		长时间格式
function dateFormatTimeString(date) {
	date=new Date(date);
	var str = date.getFullYear() + "-" + dateFormatValue(date.getMonth() + 1) + "-" + dateFormatValue(date.getDate()) 
		+ " " + dateFormatValue(date.getHours()) + ":" + dateFormatValue(date.getMinutes()) + ":" + dateFormatValue(date.getSeconds());
	return str;
}

